# Dynamic Object and Rule Extensions for AWS Network Firewall Solution Release Changelog

## [1.1.1] - 2023-01-22

### Changed
- Add support for app registry
- Update CDK version to 2.5.0
