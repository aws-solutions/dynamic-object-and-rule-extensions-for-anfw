/* eslint-disable */
module.exports = {
    roots: ['<rootDir>'],
    modulePaths: ['<rootDir>'],
    testMatch: ['**/*.test.ts'],
    transform: {
        '^.+\\.tsx?$': 'ts-jest',
    },
};
